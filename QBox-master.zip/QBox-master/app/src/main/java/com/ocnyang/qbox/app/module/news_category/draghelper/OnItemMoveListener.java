package com.ocnyang.qbox.app.module.news_category.draghelper;

/**
 * Item移动后 触发
 */
public interface OnItemMoveListener {
    void onItemMove(int fromPosition, int toPosition);
}
