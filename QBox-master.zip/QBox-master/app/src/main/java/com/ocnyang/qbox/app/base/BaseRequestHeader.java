package com.ocnyang.qbox.app.base;

/**
 * 公共请求头
 *
 * @author user
 */
public class BaseRequestHeader extends BaseRequest {

}
