package com.ocnyang.qbox.app.module.start;

/*************************************************************
 * Created by OCN.Yang           * * * *   * * * *   *     * *
 * Time:2016/10/11 17:07         *     *   *         * *   * *
 * Email address:yangocn@163.com *     *   *         *   * * *
 * Web site:www.ocnyang.com      * * * *   * * * *   *     * *
 *************************************************************/


public interface SplashPresenter {
    void isFirstOpen(boolean isFirstOpen);

    void onDestroy();
}
