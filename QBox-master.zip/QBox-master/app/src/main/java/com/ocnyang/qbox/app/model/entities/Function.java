package com.ocnyang.qbox.app.model.entities;

import java.util.List;

/*******************************************************************
 * * * * *   * * * *   *     *       Created by OCN.Yang
 * *     *   *         * *   *       Time:2017/2/28 16:44.
 * *     *   *         *   * *       Email address:ocnyang@gmail.com
 * * * * *   * * * *   *     *.Yang  Web site:www.ocnyang.com
 *******************************************************************/


public class Function {

    private List<FunctionBean> function;

    public List<FunctionBean> getFunction() {
        return function;
    }

    public void setFunction(List<FunctionBean> function) {
        this.function = function;
    }

}
