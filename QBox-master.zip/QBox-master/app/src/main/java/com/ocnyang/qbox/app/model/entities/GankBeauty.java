// (c)2016 Flipboard Inc, All Rights Reserved.

package com.ocnyang.qbox.app.model.entities;

public class GankBeauty {
    public String createdAt;
    public String url;
}
