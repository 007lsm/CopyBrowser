package com.ocnyang.qbox.app.module.start;

/*************************************************************
 * Created by OCN.Yang           * * * *   * * * *   *     * *
 * Time:2016/10/11 16:57         *     *   *         * *   * *
 * Email address:yangocn@163.com *     *   *         *   * * *
 * Web site:www.ocnyang.com      * * * *   * * * *   *     * *
 *************************************************************/


public interface SplashView {
    void initContentView();

    void startWelcomeGuideActivity();

    void startHomeActivity();
}
